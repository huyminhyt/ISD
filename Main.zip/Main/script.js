// Biến toàn cục
let cart = [];
let currentUser = null;

// Xử lý form đăng nhập (chạy trong login.html)
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', async function(event) {
        event.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorMessage = document.getElementById('login-error-message');

        if (!username || !password) {
            errorMessage.textContent = 'Vui lòng điền đầy đủ thông tin!';
            return;
        }

        try {
            const response = await fetch('http://localhost:3000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await response.json();

            if (data.success) {
                currentUser = { id: data.user_id, username };
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
                UIkit.notification('Đăng nhập thành công!', { status: 'success' });
                window.location.href = 'index.html';
            } else {
                errorMessage.textContent = data.message || 'Tên tài khoản hoặc mật khẩu không đúng!';
            }
        } catch (error) {
            errorMessage.textContent = 'Lỗi kết nối đến server!';
            console.error('Lỗi khi đăng nhập:', error);
        }
    });
}

// Xử lý form đăng ký (chỉ chạy trong register.html)
if (document.getElementById('registerForm')) {
    document.getElementById('registerForm').addEventListener('submit', async function(event) {
        event.preventDefault();

        const username = document.getElementById('reg-username').value;
        const password = document.getElementById('reg-password').value;
        const registerMessage = document.getElementById('register-message');

        if (!username || !password) {
            registerMessage.textContent = 'Vui lòng điền đầy đủ thông tin!';
            registerMessage.classList.remove('success');
            registerMessage.classList.add('error');
            return;
        }

        try {
            const response = await fetch('http://localhost:3000/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await response.json();

            if (data.success) {
                registerMessage.textContent = data.message || 'Đăng ký thành công! Vui lòng đăng nhập.';
                registerMessage.classList.remove('error');
                registerMessage.classList.add('success');
                document.getElementById('registerForm').reset();
            } else {
                registerMessage.textContent = data.message || 'Đăng ký thất bại!';
                registerMessage.classList.remove('success');
                registerMessage.classList.add('error');
            }
        } catch (error) {
            registerMessage.textContent = 'Lỗi kết nối đến server!';
            registerMessage.classList.remove('success');
            registerMessage.classList.add('error');
            console.error('Lỗi khi đăng ký:', error);
        }
    });
}

// Hàm lấy danh sách sản phẩm từ backend
async function fetchProducts() {
    try {
        const response = await fetch('http://localhost:3000/api/products');
        const products = await response.json();
        displayProducts(products);
    } catch (err) {
        console.error('Lỗi khi lấy sản phẩm:', err);
        UIkit.notification('Không thể tải sản phẩm!', { status: 'danger' });
    }
}

// Hàm hiển thị sản phẩm
function displayProducts(products) {
    const productGrid = document.querySelector('.product-grid');
    if (!productGrid) return;
    productGrid.innerHTML = '';
    products.forEach((product) => {
        const div = document.createElement('div');
        div.className = 'product-item';
        div.innerHTML = `
            <img src="${product.image_url}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price.toLocaleString()}đ</p>
            <button onclick="addToCart(${product.product_id}, '${product.name}', ${product.price})">Thêm vào giỏ hàng</button>
        `;
        productGrid.appendChild(div);
    });
}

// Hàm thêm sản phẩm vào giỏ hàng
function addToCart(productId, name, price) {
    const existingItem = cart.find((item) => item.product_id === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ product_id: productId, name, price, quantity: 1 });
    }
    updateCart();
    UIkit.notification('Đã thêm vào giỏ hàng!', { status: 'success' });
}

// Hàm cập nhật giỏ hàng
function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    const cartCount = document.getElementById('cart-count');
    if (!cartItems || !cartTotal || !cartCount) return;

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;

    cartItems.innerHTML = '';
    cart.forEach((item) => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - ${item.price.toLocaleString()}đ x ${item.quantity}`;
        cartItems.appendChild(li);
    });

    const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    cartTotal.textContent = `${totalPrice.toLocaleString()}đ`;
}

// Hàm xử lý thanh toán
async function checkout() {
    if (cart.length === 0) {
        UIkit.notification('Giỏ hàng trống!', { status: 'warning' });
        return;
    }
    if (!currentUser) {
        UIkit.notification('Vui lòng đăng nhập để thanh toán!', { status: 'warning' });
        window.location.href = 'login.html';
        return;
    }

    const customer = {
        name: 'Nguyen Van A',
        phone: '0901234567',
        email: 'nguyenvana@example.com',
        address: '123 Đường Láng, Hà Nội'
    };

    try {
        const customerResponse = await fetch('http://localhost:3000/api/customers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(customer)
        });
        const customerData = await customerResponse.json();

        const invoiceResponse = await fetch('http://localhost:3000/api/invoices', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: currentUser.id, customer: customerData, items: cart })
        });
        const invoiceData = await invoiceResponse.json();

        if (invoiceData.success) {
            UIkit.modal.alert('Cảm ơn bạn đã mua hàng! Đơn hàng của bạn đã được ghi nhận.');
            cart = [];
            updateCart();
        } else {
            throw new Error(invoiceData.message);
        }
    } catch (err) {
        console.error('Lỗi khi thanh toán:', err);
        UIkit.notification('Có lỗi xảy ra khi thanh toán!', { status: 'danger' });
    }
}

// Hà