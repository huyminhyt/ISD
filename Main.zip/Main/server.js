const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bcrypt = require('bcrypt');

const app = express();

// Sử dụng CORS và JSON parsing
app.use(cors());
app.use(express.json());

// Route mặc định để tránh lỗi "Cannot GET /"
app.get('/', (req, res) => {
    res.send('Server is running! Use /login, /register, or /api endpoints.');
});

// Kết nối đến SQLite database
const db = new sqlite3.Database('./database.sqlite', (err) => {
    if (err) {
        console.error('Error connecting to SQLite:', err.message);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Hàm khởi tạo cơ sở dữ liệu
function initializeDatabase() {
    // Tạo bảng D_USERS
    db.run(`CREATE TABLE IF NOT EXISTS D_USERS (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )`, (err) => {
        if (err) console.error('Lỗi tạo bảng D_USERS:', err.message);
    });

    // Tạo bảng D_SAN_PHAM
    db.run(`CREATE TABLE IF NOT EXISTS D_SAN_PHAM (
        product_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        image_url TEXT,
        category TEXT
    )`, (err) => {
        if (err) console.error('Lỗi tạo bảng D_SAN_PHAM:', err.message);
        else seedProducts();
    });

    // Tạo bảng D_CUSTOMER
    db.run(`CREATE TABLE IF NOT EXISTS D_CUSTOMER (
        customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        address TEXT
    )`, (err) => {
        if (err) console.error('Lỗi tạo bảng D_CUSTOMER:', err.message);
    });

    // Tạo bảng FCT_INVOICE với khóa ngoại sửa thành D_USERS
    db.run(`CREATE TABLE IF NOT EXISTS FCT_INVOICE (
        invoice_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        total_amount REAL NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES D_USERS(id),
        FOREIGN KEY (customer_id) REFERENCES D_CUSTOMER(customer_id)
    )`, (err) => {
        if (err) console.error('Lỗi tạo bảng FCT_INVOICE:', err.message);
    });

    // Tạo bảng INVOICE_ITEMS
    db.run(`CREATE TABLE IF NOT EXISTS INVOICE_ITEMS (
        invoice_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (invoice_id) REFERENCES FCT_INVOICE(invoice_id),
        FOREIGN KEY (product_id) REFERENCES D_SAN_PHAM(product_id)
    )`, (err) => {
        if (err) console.error('Lỗi tạo bảng INVOICE_ITEMS:', err.message);
    });
}

// Hàm seed dữ liệu mẫu cho D_SAN_PHAM
function seedProducts() {
    db.get(`SELECT COUNT(*) as count FROM D_SAN_PHAM`, (err, row) => {
        if (err) {
            console.error('Error checking D_SAN_PHAM:', err.message);
            return;
        }
        if (row.count === 0) {
            const products = [
                ['Viên Đẹp CumarGold Beauty', 315000, 'path-to-product-image1.jpg', 'Làm đẹp'],
                ['Combo Làm Đẹp', 539000, 'path-to-product-image2.jpg', 'Làm đẹp'],
                ['Mặt Nạ CumarGold Beauty', 235000, 'path-to-product-image3.jpg', 'Làm đẹp'],
                ['Combo Sức Sinh', 539000, 'path-to-product-image4.jpg', 'Sức sinh']
            ];

            const stmt = db.prepare(`INSERT INTO D_SAN_PHAM (name, price, image_url, category) VALUES (?, ?, ?, ?)`);
            products.forEach((product) => {
                stmt.run(product);
            });
            stmt.finalize(() => {
                console.log('Sample products inserted into D_SAN_PHAM');
            });
        }
    });
}

// API đăng ký
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Vui lòng nhập đầy đủ tên tài khoản và mật khẩu!' });
    }

    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server khi mã hóa mật khẩu!' });
        }

        db.run(`INSERT INTO D_USERS (username, password) VALUES (?, ?)`, [username, hashedPassword], function(err) {
            if (err) {
                if (err.message.includes('UNIQUE constraint failed')) {
                    return res.status(400).json({ success: false, message: 'Tên tài khoản đã tồn tại!' });
                }
                return res.status(500).json({ success: false, message: 'Lỗi server!' });
            }
            res.json({ success: true, message: 'Đăng ký thành công!' });
        });
    });
});

// API đăng nhập
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get(`SELECT * FROM D_USERS WHERE username = ?`, [username], (err, row) => {
        if (err) {
            res.status(500).json({ success: false, message: 'Lỗi server!' });
        } else if (!row) {
            res.status(401).json({ success: false, message: 'Tên tài khoản hoặc mật khẩu không đúng!' });
        } else {
            bcrypt.compare(password, row.password, (err, result) => {
                if (result) {
                    res.json({ success: true, user_id: row.id });
                } else {
                    res.status(401).json({ success: false, message: 'Tên tài khoản hoặc mật khẩu không đúng!' });
                }
            });
        }
    });
});

// API để lấy danh sách sản phẩm
app.get('/api/products', (req, res) => {
    db.all(`SELECT * FROM D_SAN_PHAM`, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server!' });
        }
        res.json(rows);
    });
});

// API để tạo hoặc lấy khách hàng
app.post('/api/customers', (req, res) => {
    const { name, phone, email, address } = req.body;

    if (!name || !phone) {
        return res.status(400).json({ success: false, message: 'Vui lòng nhập đầy đủ họ tên và số điện thoại!' });
    }

    db.get(`SELECT * FROM D_CUSTOMER WHERE phone = ?`, [phone], (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server!' });
        }

        if (row) {
            return res.json(row);
        }

        db.run(
            `INSERT INTO D_CUSTOMER (name, phone, email, address) VALUES (?, ?, ?, ?)`,
            [name, phone, email || null, address || null],
            function(err) {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Lỗi server!' });
                }
                const customerId = this.lastID;
                res.json({ customer_id: customerId, name, phone, email, address });
            }
        );
    });
});

// API để tạo hóa đơn (checkout)
app.post('/api/invoices', (req, res) => {
    const { user_id, customer, items } = req.body;

    if (!user_id || !customer || !items || items.length === 0) {
        return res.status(400).json({ success: false, message: 'Dữ liệu không hợp lệ!' });
    }

    db.get(`SELECT * FROM D_CUSTOMER WHERE phone = ?`, [customer.phone], (err, customerRow) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server!' });
        }

        let customerId;
        if (customerRow) {
            customerId = customerRow.customer_id;
        } else {
            db.run(
                `INSERT INTO D_CUSTOMER (name, phone, email, address) VALUES (?, ?, ?, ?)`,
                [customer.name, customer.phone, customer.email || null, customer.address || null],
                function(err) {
                    if (err) {
                        return res.status(500).json({ success: false, message: 'Lỗi server!' });
                    }
                    customerId = this.lastID;
                    createInvoice(customerId);
                }
            );
            return;
        }

        createInvoice(customerId);
    });

    function createInvoice(customerId) {
        const totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

        db.run(
            `INSERT INTO FCT_INVOICE (user_id, customer_id, total_amount, created_at) VALUES (?, ?, ?, ?)`,
            [user_id, customerId, totalAmount, new Date().toISOString()],
            function(err) {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Lỗi server!' });
                }

                const invoiceId = this.lastID;

                const stmt = db.prepare(
                    `INSERT INTO INVOICE_ITEMS (invoice_id, product_id, quantity, price) VALUES (?, ?, ?, ?)`
                );
                items.forEach((item) => {
                    stmt.run(invoiceId, item.product_id, item.quantity, item.price);
                });
                stmt.finalize((err) => {
                    if (err) {
                        return res.status(500).json({ success: false, message: 'Lỗi server!' });
                    }
                    res.status(201).json({
                        success: true,
                        invoice_id: invoiceId,
                        user_id,
                        customer_id: customerId,
                        total_amount: totalAmount,
                        items
                    });
                });
            }
        );
    }
});

// API để lấy danh sách đơn hàng của người dùng
app.get('/api/orders', (req, res) => {
    const { user_id } = req.query;

    if (!user_id) {
        return res.status(400).json({ success: false, message: 'Thiếu user_id!' });
    }

    db.all(
        `SELECT i.invoice_id, i.total_amount, i.created_at, c.name AS customer_name, c.phone, c.address
         FROM FCT_INVOICE i
         JOIN D_CUSTOMER c ON i.customer_id = c.customer_id
         WHERE i.user_id = ?`,
        [user_id],
        (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Lỗi server!' });
            }
            res.json(rows);
        }
    );
});

// API lấy thông tin tài khoản
app.get('/api/user/:id', (req, res) => {
    const userId = req.params.id;

    db.get(`SELECT username, email, phone, address FROM D_USERS WHERE id = ?`, [userId], (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server!' });
        }
        if (!row) {
            return res.status(404).json({ success: false, message: 'Người dùng không tồn tại!' });
        }
        res.json({ success: true, user: row });
    });
});

// API đổi mật khẩu
app.post('/api/change-password', (req, res) => {
    const { user_id, current_password, new_password } = req.body;

    if (!user_id || !current_password || !new_password) {
        return res.status(400).json({ success: false, message: 'Vui lòng điền đầy đủ thông tin!' });
    }

    db.get(`SELECT password FROM D_USERS WHERE id = ?`, [user_id], (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Lỗi server!' });
        }
        if (!row) {
            return res.status(404).json({ success: false, message: 'Người dùng không tồn tại!' });
        }

        bcrypt.compare(current_password, row.password, (err, result) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Lỗi server!' });
            }
            if (!result) {
                return res.status(401).json({ success: false, message: 'Mật khẩu hiện tại không đúng!' });
            }

            bcrypt.hash(new_password, 10, (err, hashedPassword) => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Lỗi server!' });
                }

                db.run(`UPDATE D_USERS SET password = ? WHERE id = ?`, [hashedPassword, user_id], (err) => {
                    if (err) {
                        return res.status(500).json({ success: false, message: 'Lỗi server!' });
                    }
                    res.json({ success: true, message: 'Đổi mật khẩu thành công!' });
                });
            });
        });
    });
});

// Khởi động server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});